#include <iostream>
#include <cstdio>
#include <cstdlib>
using namespace std;

class Base {
public:
    Base(int val): val(val) {}
    int getVal() const {
        return val;
    }
    int setVal(int newVal) {
        val = newVal;
    }
private:
    int val;
};

class Derived: private Base {
public:
    Derived(int val, int times): Base(val), times(times) {}
    int getVal() const {
        return Base::getVal();
    }
    int setVal(int newVal) {
        Base::setVal(newVal);
    }
    int getPlus() const {
        return Base::getVal() * times;
    }
private:
    int times;
};

int main() {
    freopen("in.txt", "r", stdin);
    freopen("out.txt", "w", stdout);
    int a, b;
    while (cin >> a >> b) {
        Derived d(a, b);
        cout << d.getVal() << endl;
        cout << d.getPlus() << endl;
        d.setVal(2016);
        cout << d.getVal() << endl;
        cout << d.getPlus() << endl;
    }
    return 0;
}