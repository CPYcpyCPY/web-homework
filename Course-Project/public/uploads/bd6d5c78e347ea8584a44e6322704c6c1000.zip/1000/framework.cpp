#include <iostream>
using namespace std;

class Base {
public:
    Base(int val): val(val) {}
    int getVal() const {
        return val;
    }
    int setVal(int newVal) {
        val = newVal;
    }
private:
    int val;
};

class Derived: private Base {
public:
    #include "source.cpp"
private:
    int times;
};

int main() {
    int a, b;
    while (cin >> a >> b) {
        Derived d(a, b);
        cout << d.getVal() << endl;
        cout << d.getPlus() << endl;
        d.setVal(2016);
        cout << d.getVal() << endl;
        cout << d.getPlus() << endl;
    }
    return 0;
}